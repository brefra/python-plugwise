"""Support for Plugwise power sensors."""
import logging

from plugwise.util import PlugwiseException

from homeassistant.const import DEVICE_CLASS_POWER, POWER_WATT
from homeassistant.helpers import template

from . import PlugwiseNodeEntity
from .const import DOMAIN

_LOGGER = logging.getLogger(__name__)


ATTR_RSSI_IN = "RSSI in"
ATTR_RSSI_OUT = "RSSI out"
ATTR_PING = "Ping"
ATTR_LAST_UPDATE = "Last update"
ATTR_POWER_HOUR = "Power use last hour (kWh)"
ATTR_POWER_TODAY = "Power use today (kWh)"
ATTR_POWER_YESTERDAY = "Power use yesterday (kWh)"
ATTR_FIRMWARE = "Firmware version"
ATTR_HARDWARE = "Hardware version"


async def async_setup_entry(hass, entry, async_add_entities):
    """Set up Plugwise sensor based on config_entry."""
    stick = hass.data[DOMAIN][entry.entry_id]["stick"]
    nodes_data = hass.data[DOMAIN][entry.entry_id]["sensor"]
    entities = []
    for mac in nodes_data:
        node = stick.node(mac)
        entities.append(PlugwiseSensor(node, mac))
    async_add_entities(entities)


class PlugwiseSensor(PlugwiseNodeEntity):
    """Representation of a sensor."""

    @property
    def unique_id(self):
        """Get unique ID."""
        return f"{self._mac}-Sensor"

    @property
    def device_class(self):
        """Return the device class of the sensor."""
        return DEVICE_CLASS_POWER

    @property
    def state(self):
        """Return the state of the sensor."""
        return float(round(self._node.get_power_usage(), 2))

    @property
    def unit_of_measurement(self):
        """Return the unit this state is expressed in."""
        return POWER_WATT

    @property
    def device_state_attributes(self):
        """Return the state attributes of the device."""
        attr = {}
        attr[ATTR_POWER_HOUR] = float(round(self._node.get_power_use_last_hour() / 1000, 3))
        attr[ATTR_POWER_TODAY] = float(round(self._node.get_power_use_today() / 1000, 3))
        attr[ATTR_POWER_YESTERDAY] = float(round(self._node.get_power_use_yesterday() / 1000, 3))
        attr[ATTR_RSSI_IN] = int(self._node.get_in_RSSI())
        attr[ATTR_RSSI_OUT] = int(self._node.get_out_RSSI())
        attr[ATTR_PING] = int(self._node.get_ping())
        attr[ATTR_FIRMWARE] = self._node.get_firmware_version()
        attr[ATTR_HARDWARE] = self._node.get_hardware_version()
        attr[ATTR_LAST_UPDATE] = template.timestamp_local(self._node.get_last_update())

        return attr