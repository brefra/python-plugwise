"""Support for Plugwise Circle(+) nodes."""
import logging

from plugwise.util import PlugwiseException

from homeassistant.components.switch import SwitchDevice

from . import PlugwiseNodeEntity
from .const import DOMAIN

_LOGGER = logging.getLogger(__name__)


async def async_setup_entry(hass, entry, async_add_entities):
    """Set up Plugwise switch based on config_entry."""
    stick = hass.data[DOMAIN][entry.entry_id]["stick"]
    nodes_data = hass.data[DOMAIN][entry.entry_id]["switch"]
    entities = []
    for mac in nodes_data:
        node = stick.node(mac)
        entities.append(PlugwiseSwitch(node, mac))
    async_add_entities(entities)


class PlugwiseSwitch(PlugwiseNodeEntity, SwitchDevice):
    """Representation of a switch."""

    @property
    def unique_id(self):
        """Get unique ID."""
        return f"{self._mac}-switch"

    @property
    def is_on(self):
        """Return true if the switch is on."""
        return self._node.is_on()

    @property
    def icon(self):
        """Return the icon."""
        return "mdi:power-socket-eu"
    
    def turn_on(self, **kwargs):
        """Instruct the switch to turn on."""
        try:
            self._node.turn_on()
        except PlugwiseException as err:
            _LOGGER.error("A Plugswise error occurred: %s", err)

    def turn_off(self, **kwargs):
        """Instruct the switch to turn off."""
        try:
            self._node.turn_off()
        except PlugwiseException as err:
            _LOGGER.error("A Plugwise error occurred: %s", err)

    @property
    def current_power_w(self):
        """Return the current power usage in W."""
        return float(round(self._node.get_power_usage(), 2))

    @property
    def today_energy_kwh(self):
        """Return the today total energy usage in kWh."""
        return float(round(self._node.get_power_use_today() / 1000, 3))