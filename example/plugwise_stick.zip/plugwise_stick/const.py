"""Const for Plugwise stick."""

DOMAIN = "plugwise_stick"
PLUGWISE_CONFIG_NAME = "Plugwise stick config"

CALLBACK_RELAY = "RELAY"
CALLBACK_POWER = "POWER"
