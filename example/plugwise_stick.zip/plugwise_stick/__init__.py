"""Support for Plugwise devices connected to a Plugwise stick."""
import asyncio
import logging
import plugwise
import voluptuous as vol

from homeassistant.config_entries import SOURCE_IMPORT, ConfigEntry
from homeassistant.const import CONF_NAME, CONF_PORT
from homeassistant.exceptions import ConfigEntryNotReady
import homeassistant.helpers.config_validation as cv
from homeassistant.helpers import template
from homeassistant.helpers.entity import Entity
from homeassistant.helpers.typing import HomeAssistantType

from .const import AVAILABLE_SENSOR_ID, DOMAIN, PLUGWISE_CONFIG_NAME, SENSORS

_LOGGER = logging.getLogger(__name__)

CONFIG_SCHEMA = vol.Schema(
    {DOMAIN: vol.Schema({vol.Required(CONF_PORT): cv.string})}, extra=vol.ALLOW_EXTRA
)

COMPONENT_TYPES = ["switch", "sensor"]


async def async_setup(hass, config):
    """Set up the Plugwise stick platform."""
    if DOMAIN not in config:
        return True
    port = config[DOMAIN].get(CONF_PORT)
    data = {}

    if port:
        data = {CONF_PORT: port, CONF_NAME: PLUGWISE_CONFIG_NAME}
    hass.async_create_task(
        hass.config_entries.flow.async_init(
            DOMAIN, context={"source": SOURCE_IMPORT}, data=data
        )
    )

    return True


async def async_setup_entry(hass: HomeAssistantType, entry: ConfigEntry):
    """Establish connection with plugwise stick."""
    hass.data.setdefault(DOMAIN, {})

    def discover_nodes():
        _LOGGER.debug("Connected, start discovery of plugwise nodes")
        stick.scan(discover_finished)

    def discover_finished():
        nodes = stick.nodes()
        _LOGGER.debug("Discovery finished %s nodes found", str(len(nodes)))
        discovery_info = {"stick": stick}
        for category in COMPONENT_TYPES:
            discovery_info[category] = []
        for mac in nodes:
            for category in COMPONENT_TYPES:
                if category in stick.node(mac).get_categories():
                    discovery_info[category].append(mac)
        hass.data[DOMAIN][entry.entry_id] = discovery_info
        for category in COMPONENT_TYPES:
            hass.add_job(hass.config_entries.async_forward_entry_setup(entry, category))
        stick.auto_update()

    try:
        _LOGGER.debug("Connect to Plugwise stick")
        stick = plugwise.stick(entry.data[CONF_PORT], discover_nodes)
    except plugwise.util.PlugwiseException as err:
        _LOGGER.error("An error occurred: %s", err)
        raise ConfigEntryNotReady
    return True


async def async_unload_entry(hass: HomeAssistantType, entry: ConfigEntry):
    """Remove the Plugwise stick connection."""
    await asyncio.wait(
        [
            hass.config_entries.async_forward_entry_unload(entry, component)
            for component in COMPONENT_TYPES
        ]
    )
    hass.data[DOMAIN][entry.entry_id]["stick"].stop()
    hass.data[DOMAIN].pop(entry.entry_id)
    if not hass.data[DOMAIN]:
        hass.data.pop(DOMAIN)
    return True


class PlugwiseNodeEntity(Entity):
    """Representation of a Plugwise Node entity."""

    def __init__(self, node, mac):
        """Initialize a Node entity."""
        self._node = node
        self._mac = mac
        self.node_callbacks = (AVAILABLE_SENSOR_ID,)

    async def async_added_to_hass(self):
        """Subscribe to updates"""
        for node_callback in self.node_callbacks:
            self._node.subscribe_callback(self.sensor_update, node_callback)

    async def async_will_remove_from_hass(self):
        """Unsubscribe from updates"""
        for node_callback in self.node_callbacks:
            self._node.unsubscribe_callback(self.sensor_update, node_callback)

    @property
    def available(self):
        """Return the availability of this entity."""
        return getattr(self._node, SENSORS[AVAILABLE_SENSOR_ID]["state"])()

    @property
    def device_info(self):
        """Return the device info."""
        return {
            "identifiers": {(DOMAIN, self._mac)},
            "name": "{} ({})".format(self._node.get_node_type(), self._mac),
            "manufacturer": "Plugwise",
            "model": self._node.get_node_type(),
            "sw_version": "{}".format(self._node.get_firmware_version(),),
        }

    @property
    def name(self):
        """Return the display name of this entity."""
        return f"{self._node.get_node_type()} {self._mac[-5:]}"

    def sensor_update(self, state):
        """Handle status update of Entity"""
        self.schedule_update_ha_state()

    @property
    def should_poll(self):
        """Disable polling."""
        return False

    @property
    def unique_id(self):
        """Get unique ID."""
        return f"{self._mac}-{self._node.get_node_type()}"
